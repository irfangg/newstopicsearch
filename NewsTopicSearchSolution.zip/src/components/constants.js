export const BASE_URL ='http://content.guardianapis.com/search';
export const API_KEY = 'test';
export const urlFields = '&show-fields=thumbnail,headline&show-tags=keyword&page=1&page-size=10';